﻿import std;
import <Puzzle.Runtime/Functions/AntiDebuggers.hpp>;
import <Puzzle.Runtime/Functions/TokenValidater.hpp>;
import <Puzzle.Runtime/Utils/Logger.hpp>;
import <Puzzle.Runtime/Utils/ArgsParser.hpp>;
import <Puzzle.Runtime/Functions/FlagPrinter.hpp>;
import <Windows.h>;

int main(const int argc, const char *argv[]) {
  using namespace Puzzle;
  Runtime::Utils::Logger logger("Puzzle.App");
  try {
    if (Runtime::Functions::AntiDebuggers::Check()) {
      throw std::runtime_error("DebugCheck failed.");
    } else {
      logger.debug("Passed all DebugCheck tests.");
    }
    Runtime::Utils::ArgsParser argsParser(argc, argv);

    if (argsParser.has("genToken")) {
      auto type = argsParser.get("genToken", "unknown");
      std::string token;
      if (type == "correct") {
        token = Runtime::Functions::TokenValidater::generate(
            Runtime::Functions::TokenValidater::TokenType::CORRECT);
      } else if (type == "trap") {
        token = Runtime::Functions::TokenValidater::generate(
            Runtime::Functions::TokenValidater::TokenType::TRAP);
      } else {
        throw std::runtime_error("Unknown Token type.");
      }
      logger.info("Token: {}", token);
      return 0;
    }

    if (argsParser.has("token")) {
      auto token = argsParser.get("token", "null");
      auto result = Runtime::Functions::TokenValidater::validate(token);
      if (result == Runtime::Functions::TokenValidater::TokenType::UNKNOWN) {
        if (token == "null") {
          logger.error("Token is null.");
        }
        if (token == "CCB") {
          ShellExecute(nullptr, L"open",
                       L"https://www.bilibili.com/video/BV1B2R3YkEt9", nullptr,
                       nullptr, SW_SHOWNORMAL);
          return 114514;
        }
        throw std::runtime_error("Invalid Token!");
      }

      Runtime::Functions::FlagPrinter::print(token);
      return 0;

      if (result == Runtime::Functions::TokenValidater::TokenType::CORRECT) {
        logger.info("Token is valid.");
      } else if (result ==
                 Runtime::Functions::TokenValidater::TokenType::TRAP) {
        logger.warn("Token is a trap.");
      } else {
        logger.error("Token is invalid.");
      }
    }

    if (argsParser.has("78")) {
      logger.info("PDc+a1ZsV1dYdzQ4bzw4PjJ0OTVVTE9n");
      return 78;
    }

    logger.info("Need a Token.");
    logger.info("If you have a token, use \"./Puzzle.App --token your-token\" "
                "to continue.");
    return 1;

  } catch (std::exception &e) {
    logger.error("Exception: {}", e.what());
    return -1;
  }
}