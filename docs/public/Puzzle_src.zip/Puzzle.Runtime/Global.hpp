#pragma once
// macro for api export
#ifndef PUZZLERUNTIME_EXPORTS
#define PUZZLE_RUNTIME_API __declspec(dllimport)
#else
#define PUZZLE_RUNTIME_API __declspec(dllexport)
#endif // !PUZZLERUNTIME_EXPORTS

#define PUZZLE_RUNTIME_NDAPI [[nodiscard]] PUZZLE_RUNTIME_API