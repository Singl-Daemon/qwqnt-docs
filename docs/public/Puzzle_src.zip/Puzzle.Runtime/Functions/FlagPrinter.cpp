import std;
import <Puzzle.Runtime/Functions/FlagPrinter.hpp>;
import <Puzzle.Runtime/Utils/Logger.hpp>;
import <Puzzle.Runtime/Functions/RandomFlag.hpp>;
import <Puzzle.Runtime/Functions/TokenValidater.hpp>;
import <Puzzle.Runtime/Utils/Flag.hpp>;

namespace Puzzle::Runtime::Functions {
void FlagPrinter::print(std::string_view token) {
  using namespace Utils::Flag::literals;

  Utils::Logger logger("Puzzle.Runtime");
  const auto fmt = "Congratulations! {}";
  const auto trueFlag = "https://t.me/+DDiJjs3Mu-lkMzI1"_flag;

  auto result = Runtime::Functions::TokenValidater::validate(token);
  if (result == TokenValidater::TokenType::CORRECT) {
    logger.info(fmt, trueFlag);
  }
  if (result == TokenValidater::TokenType::TRAP)
    logger.info(fmt, RandomFlag::getInstance().GetRandomFlag());
}
} // namespace Puzzle::Runtime::Functions