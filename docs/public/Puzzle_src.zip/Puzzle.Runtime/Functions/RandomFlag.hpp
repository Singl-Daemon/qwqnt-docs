#pragma once
import std;
import <Puzzle.Runtime/Global.hpp>;

namespace Puzzle::Runtime::Functions {
class RandomFlag {
public:
  PUZZLE_RUNTIME_NDAPI static RandomFlag &getInstance();
  PUZZLE_RUNTIME_NDAPI std::string_view GetRandomFlag();

private:
  RandomFlag();

  std::vector<std::string> flags;
};
} // namespace Puzzle::Runtime::Functions