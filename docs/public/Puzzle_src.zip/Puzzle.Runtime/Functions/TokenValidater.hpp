﻿import std;
import <Puzzle.Runtime/Global.hpp>;

namespace Puzzle::Runtime::Functions {

class TokenValidater {
public:
  enum class TokenType : int {
    UNKNOWN = -1,
    CORRECT = 0,
    TRAP = 114514,
  };

  PUZZLE_RUNTIME_NDAPI static std::string generate(TokenType type);
  PUZZLE_RUNTIME_NDAPI static TokenType validate(std::string_view token);
};
} // namespace Puzzle::Runtime::Functions