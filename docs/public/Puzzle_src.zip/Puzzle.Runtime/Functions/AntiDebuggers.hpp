#pragma once
import <Puzzle.Runtime/Global.hpp>;

namespace Puzzle::Runtime::Functions {
class AntiDebuggers {
public:
  // return true if any debugger is detected
  PUZZLE_RUNTIME_NDAPI static bool Check();

private:
  static bool check_debugger_present();
  static bool check_remote_debugger();
  static bool check_hardware_breakpoints();
  static bool check_nt_global_flag();
  static bool check_seh();
};

} // namespace Puzzle::Runtime::Functions