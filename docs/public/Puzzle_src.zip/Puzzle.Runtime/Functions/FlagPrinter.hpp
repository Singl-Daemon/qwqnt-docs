import std;
import <Puzzle.Runtime/Global.hpp>;

namespace Puzzle::Runtime::Functions {

class FlagPrinter {
public:
  PUZZLE_RUNTIME_API static void print(std::string_view token);
};
} // namespace Puzzle::Runtime::Functions