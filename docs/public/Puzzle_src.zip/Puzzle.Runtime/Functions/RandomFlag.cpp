import std;
import <Puzzle.Runtime/Functions/RandomFlag.hpp>;
import <Puzzle.Runtime/Utils/Flag.hpp>;

namespace Puzzle::Runtime::Functions {

RandomFlag &RandomFlag::getInstance() {
  static RandomFlag randomFlag;
  return randomFlag;
}

std::string_view RandomFlag::GetRandomFlag() {
  static std::mt19937 generator(std::random_device{}());
  std::uniform_int_distribution<size_t> distribution(0, flags.size() - 1);
  size_t index = distribution(generator);
  const std::string &selectedFlag = flags[index];
  return selectedFlag;
}

RandomFlag::RandomFlag() {
  using namespace Puzzle::Runtime::Utils::Flag::literals;
  flags = { "https://www.bilibili.com/video/BV1wV4EzrEwx"_flag,
           "https://www.bilibili.com/video/BV1Nv4y1u7qc"_flag,
           "https://www.bilibili.com/video/BV1xx411c7BF"_flag,
           "https://www.bilibili.com/video/BV1UXaczmEp7"_flag,
           "https://www.bilibili.com/video/BV186pUzfER3"_flag,
  };
}

} // namespace Puzzle::Runtime::Functions