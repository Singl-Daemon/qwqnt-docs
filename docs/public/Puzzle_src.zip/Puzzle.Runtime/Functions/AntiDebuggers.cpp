﻿import std;
import <Windows.h>;
import <Puzzle.Runtime/Utils/Logger.hpp>;
import <Puzzle.Runtime/Functions/AntiDebuggers.hpp>;

#include <winternl.h>

#pragma comment(lib, "ntdll.lib")

namespace Puzzle::Runtime::Functions {


__forceinline bool AntiDebuggers::check_debugger_present() {
  return IsDebuggerPresent() != 0;
}

__forceinline bool AntiDebuggers::check_remote_debugger() {
  BOOL isDebuggerPresent = FALSE;
  CheckRemoteDebuggerPresent(GetCurrentProcess(), &isDebuggerPresent);
  return isDebuggerPresent != 0;
}

__forceinline bool AntiDebuggers::check_hardware_breakpoints() {
  CONTEXT ctx = {};
  ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
  GetThreadContext(GetCurrentThread(), &ctx);
  return (ctx.Dr0 != 0 || ctx.Dr1 != 0 || ctx.Dr2 != 0 || ctx.Dr3 != 0);
}

__forceinline bool AntiDebuggers::check_nt_global_flag() {
  ULONG noDebugInherit = 0;
  NTSTATUS st = NtQueryInformationProcess(
      GetCurrentProcess(),
      static_cast<PROCESSINFOCLASS>(31), // ProcessDebugFlags
      &noDebugInherit, sizeof(noDebugInherit), nullptr);

  if (NT_SUCCESS(st)) {
    return noDebugInherit == 0;
  }
  ULONG_PTR debugPort = 0;
  st = NtQueryInformationProcess(GetCurrentProcess(), ProcessDebugPort,
                                 &debugPort, sizeof(debugPort), nullptr);

  if (NT_SUCCESS(st) && debugPort != 0) {
    return true;
  }

  HANDLE debugObj = nullptr;
  st = NtQueryInformationProcess(
      GetCurrentProcess(),
      static_cast<PROCESSINFOCLASS>(30), // ProcessDebugObjectHandle
      &debugObj, sizeof(debugObj), nullptr);

  if (NT_SUCCESS(st) && debugObj != nullptr &&
      debugObj != reinterpret_cast<HANDLE>(-1)) {
    return true;
  }

#if defined(_M_X64) || defined(_WIN64)
  const auto peb = reinterpret_cast<const BYTE *>(__readgsqword(0x60));
  constexpr SIZE_T kNtGlobalFlagOffset = 0xBC; // x64
#else
  const auto peb = reinterpret_cast<const BYTE *>(__readfsdword(0x30));
  constexpr SIZE_T kNtGlobalFlagOffset = 0x68; // x86
#endif

  // FLG_HEAP_ENABLE_TAIL_CHECK | FLG_HEAP_ENABLE_FREE_CHECK |
  // FLG_HEAP_VALIDATE_PARAMETERS
  constexpr DWORD kDebugHeapFlags = 0x10 | 0x20 | 0x40;
  const DWORD ntGlobalFlag =
      *reinterpret_cast<const DWORD *>(peb + kNtGlobalFlagOffset);
  return (ntGlobalFlag & kDebugHeapFlags) != 0;
}

__forceinline bool AntiDebuggers::check_seh() {
  __try {
    __try {
      DebugBreak();
    } __except (EXCEPTION_EXECUTE_HANDLER) {
      return false;
    }
  } __except (EXCEPTION_EXECUTE_HANDLER) {
    return true;
  }
  return true;
}

bool AntiDebuggers::Check() {
  const bool dbg = check_debugger_present();
  const bool remote = check_remote_debugger();
  const bool hw = check_hardware_breakpoints();
  const bool nt = check_nt_global_flag();
  const bool seh = check_seh();
  return dbg || remote || hw || nt || seh;
}
} // namespace Puzzle::App::AntiDebuggers