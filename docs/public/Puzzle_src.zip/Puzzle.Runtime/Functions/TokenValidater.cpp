﻿import std;
import <Puzzle.Runtime/Functions/TokenValidater.hpp>;
import <Windows.h>;

#include <bcrypt.h>

#pragma comment(lib, "bcrypt.lib")

namespace Puzzle::Runtime::Functions {
namespace {

    // 以下内容均为AI生成
    // vibe coding太好用了你们知道吗

constexpr char kB64UrlTable[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

std::string base64url_encode(std::span<const std::byte> bytes) {
  const std::uint8_t *data =
      reinterpret_cast<const std::uint8_t *>(bytes.data());
  size_t len = bytes.size();

  std::string out;
  out.reserve(((len + 2) / 3) * 4);

  size_t i = 0;
  while (i + 3 <= len) {
    std::uint32_t v = (std::uint32_t(data[i]) << 16) |
                      (std::uint32_t(data[i + 1]) << 8) |
                      (std::uint32_t(data[i + 2]));
    out.push_back(kB64UrlTable[(v >> 18) & 0x3F]);
    out.push_back(kB64UrlTable[(v >> 12) & 0x3F]);
    out.push_back(kB64UrlTable[(v >> 6) & 0x3F]);
    out.push_back(kB64UrlTable[(v) & 0x3F]);
    i += 3;
  }

  if (i + 1 == len) {
    std::uint32_t v = (std::uint32_t(data[i]) << 16);
    out.push_back(kB64UrlTable[(v >> 18) & 0x3F]);
    out.push_back(kB64UrlTable[(v >> 12) & 0x3F]);
  } else if (i + 2 == len) {
    std::uint32_t v =
        (std::uint32_t(data[i]) << 16) | (std::uint32_t(data[i + 1]) << 8);
    out.push_back(kB64UrlTable[(v >> 18) & 0x3F]);
    out.push_back(kB64UrlTable[(v >> 12) & 0x3F]);
    out.push_back(kB64UrlTable[(v >> 6) & 0x3F]);
  }
  return out;
}

inline std::uint8_t b64url_inv(char c) {
  if (c >= 'A' && c <= 'Z')
    return std::uint8_t(c - 'A');
  if (c >= 'a' && c <= 'z')
    return std::uint8_t(c - 'a' + 26);
  if (c >= '0' && c <= '9')
    return std::uint8_t(c - '0' + 52);
  if (c == '-' || c == '+')
    return 62;
  if (c == '_' || c == '/')
    return 63;
  return 0xFF;
}

std::vector<std::byte> base64url_decode(std::string_view s) {
  std::string clean;
  clean.reserve(s.size());
  for (char ch : s) {
    if (ch == '=')
      continue;
    if (ch == '+')
      clean.push_back('-');
    else if (ch == '/')
      clean.push_back('_');
    else
      clean.push_back(ch);
  }

  const size_t n = clean.size();
  if (n == 0)
    return {};

  size_t full_quads = n / 4;
  size_t rem = n % 4;

  size_t out_len = full_quads * 3;
  if (rem == 2)
    out_len += 1;
  else if (rem == 3)
    out_len += 2;
  else if (rem != 0)
    return {};

  std::vector<std::byte> out;
  out.resize(out_len);

  size_t si = 0;
  size_t oi = 0;

  auto read_quartet = [&](std::uint8_t &a, std::uint8_t &b, std::uint8_t &c,
                          std::uint8_t &d) -> bool {
    a = b64url_inv(clean[si++]);
    b = b64url_inv(clean[si++]);
    c = b64url_inv(clean[si++]);
    d = b64url_inv(clean[si++]);
    return (a | b | c | d) != 0xFF;
  };

  for (size_t q = 0; q < full_quads; ++q) {
    std::uint8_t a, b, c, d;
    if (!read_quartet(a, b, c, d))
      return {};
    std::uint32_t v = (a << 18) | (b << 12) | (c << 6) | d;
    out[oi++] = std::byte((v >> 16) & 0xFF);
    out[oi++] = std::byte((v >> 8) & 0xFF);
    out[oi++] = std::byte(v & 0xFF);
  }

  if (rem == 2) {
    std::uint8_t a = b64url_inv(clean[si++]);
    std::uint8_t b = b64url_inv(clean[si++]);
    if ((a | b) == 0xFF)
      return {};
    std::uint32_t v = (a << 18) | (b << 12);
    out[oi++] = std::byte((v >> 16) & 0xFF);
  } else if (rem == 3) {
    std::uint8_t a = b64url_inv(clean[si++]);
    std::uint8_t b = b64url_inv(clean[si++]);
    std::uint8_t c = b64url_inv(clean[si++]);
    if ((a | b | c) == 0xFF)
      return {};
    std::uint32_t v = (a << 18) | (b << 12) | (c << 6);
    out[oi++] = std::byte((v >> 16) & 0xFF);
    out[oi++] = std::byte((v >> 8) & 0xFF);
  }

  return out;
}

bool secure_equals(std::span<const std::byte> a, std::span<const std::byte> b) {
  if (a.size() != b.size())
    return false;
  unsigned char diff = 0;
  for (size_t i = 0; i < a.size(); ++i) {
    diff |= (std::to_integer<unsigned char>(a[i]) ^
             std::to_integer<unsigned char>(b[i]));
  }
  return diff == 0;
}

std::optional<std::array<std::byte, 32>>
hmac_sha256(std::span<const std::byte> key, std::span<const std::byte> data) {
  struct AlgHandle {
    BCRYPT_ALG_HANDLE h = nullptr;
    ~AlgHandle() {
      if (h)
        BCryptCloseAlgorithmProvider(h, 0);
    }
  } alg;

  struct HashHandle {
    BCRYPT_HASH_HANDLE h = nullptr;
    ~HashHandle() {
      if (h)
        BCryptDestroyHash(h);
    }
  } hash;

  NTSTATUS status = BCryptOpenAlgorithmProvider(
      &alg.h, BCRYPT_SHA256_ALGORITHM, nullptr, BCRYPT_ALG_HANDLE_HMAC_FLAG);
  if (!BCRYPT_SUCCESS(status))
    return std::nullopt;

  status = BCryptCreateHash(
      alg.h, &hash.h, nullptr, 0,
      reinterpret_cast<PUCHAR>(const_cast<std::byte *>(key.data())),
      static_cast<ULONG>(key.size()), 0);
  if (!BCRYPT_SUCCESS(status))
    return std::nullopt;

  status = BCryptHashData(
      hash.h, reinterpret_cast<PUCHAR>(const_cast<std::byte *>(data.data())),
      static_cast<ULONG>(data.size()), 0);
  if (!BCRYPT_SUCCESS(status))
    return std::nullopt;

  std::array<std::byte, 32> out{};
  status = BCryptFinishHash(hash.h, reinterpret_cast<PUCHAR>(out.data()),
                            static_cast<ULONG>(out.size()), 0);
  if (!BCRYPT_SUCCESS(status))
    return std::nullopt;

  return out;
}

bool gen_random(std::span<std::byte> out) {
  NTSTATUS status = BCryptGenRandom(
      nullptr, reinterpret_cast<PUCHAR>(out.data()),
      static_cast<ULONG>(out.size()), BCRYPT_USE_SYSTEM_PREFERRED_RNG);
  return BCRYPT_SUCCESS(status);
}

std::vector<std::byte> get_secret_key() {
  static constexpr std::uint8_t kDefaultKey[32] = {
      0x8A, 0x41, 0x33, 0x97, 0x2F, 0xC4, 0x5B, 0x12, 0x6E, 0xAC, 0xD9,
      0x52, 0xE7, 0xB1, 0x08, 0x77, 0x3A, 0x5E, 0x19, 0xC3, 0x4D, 0x81,
      0xF2, 0x0B, 0x9C, 0x6D, 0x55, 0xAA, 0x02, 0x17, 0xE4, 0xCB,
  };

  wchar_t buf[1024]{};
  DWORD got = GetEnvironmentVariableW(L"PUZZLE_TOKEN_KEY", buf, std::size(buf));
  if (got > 0 && got < std::size(buf)) {
    int utf8Len =
        WideCharToMultiByte(CP_UTF8, 0, buf, -1, nullptr, 0, nullptr, nullptr);
    std::string val;
    val.resize(utf8Len ? utf8Len - 1 : 0);
    if (utf8Len > 0) {
      WideCharToMultiByte(CP_UTF8, 0, buf, -1, val.data(), utf8Len, nullptr,
                          nullptr);
      auto decoded = base64url_decode(val);
      if (decoded.size() >= 16) {
        return decoded;
      }
    }
  }
  return std::vector<std::byte>(
      reinterpret_cast<const std::byte *>(kDefaultKey),
      reinterpret_cast<const std::byte *>(kDefaultKey) + 32);
}

#pragma pack(push, 1)
struct TokenPayloadV1 {
  std::uint8_t version;   // 1
  std::uint8_t typeMark;  // 0xC3 for CORRECT, 0x3C for TRAP
  std::uint64_t issuedAt; // Unix epoch seconds
  std::byte nonce[16];
};
#pragma pack(pop)

constexpr std::uint8_t kVersionV1 = 1;
constexpr std::uint8_t kTypeMarkCorrect = 0xC3;
constexpr std::uint8_t kTypeMarkTrap = 0x3C;

} // namespace
std::string TokenValidater::generate(TokenType type) {
  TokenPayloadV1 p{};
  p.version = kVersionV1;
  p.typeMark = (type == TokenType::TRAP) ? kTypeMarkTrap : kTypeMarkCorrect;

  FILETIME ft;
  GetSystemTimeAsFileTime(&ft);
  ULARGE_INTEGER uli;
  uli.LowPart = ft.dwLowDateTime;
  uli.HighPart = ft.dwHighDateTime;

  const std::uint64_t EPOCH_DIFF_100NS = 11644473600ULL * 10000000ULL;
  std::uint64_t now100ns = uli.QuadPart;
  std::uint64_t unixSec = (now100ns - EPOCH_DIFF_100NS) / 10000000ULL;
  p.issuedAt = unixSec;

  if (!gen_random(std::span<std::byte>(p.nonce, sizeof p.nonce))) {
    throw std::runtime_error("BCryptGenRandom failed");
  }

  std::span<const std::byte> payload{reinterpret_cast<const std::byte *>(&p),
                                     sizeof(TokenPayloadV1)};

  auto key = get_secret_key();
  auto macOpt = hmac_sha256(key, payload);
  if (!macOpt) {
    throw std::runtime_error("HMAC-SHA256 failed");
  }
  const auto &mac = *macOpt;

  std::string token;
  token.reserve(((payload.size() + mac.size() + 2) / 3) * 4);
  {
    std::vector<std::byte> buf;
    buf.reserve(payload.size() + mac.size());
    buf.insert(buf.end(), payload.begin(), payload.end());
    buf.insert(buf.end(), mac.begin(), mac.end());
    token = base64url_encode(buf);
  }
  return token;
}

TokenValidater::TokenType TokenValidater::validate(std::string_view token) {
  auto raw = base64url_decode(token);
  if (raw.size() < sizeof(TokenPayloadV1) + 32) {
    return TokenType::UNKNOWN;
  }
  if (raw.size() != sizeof(TokenPayloadV1) + 32) {
    return TokenType::UNKNOWN;
  }

  std::span<const std::byte> payload{raw.data(), sizeof(TokenPayloadV1)};
  std::span<const std::byte> mac{
      raw.data() + sizeof(TokenPayloadV1),
      raw.size() - sizeof(TokenPayloadV1),
  };

  auto key = get_secret_key();
  auto mac2Opt = hmac_sha256(key, payload);
  if (!mac2Opt)
    return TokenType::UNKNOWN;
  if (!secure_equals(
          mac, std::span<const std::byte>(mac2Opt->data(), mac2Opt->size()))) {
    return TokenType::UNKNOWN;
  }

  const auto *p = reinterpret_cast<const TokenPayloadV1 *>(payload.data());
  if (p->version != kVersionV1)
    return TokenType::UNKNOWN;

  if (p->typeMark == kTypeMarkCorrect)
    return TokenType::CORRECT;
  if (p->typeMark == kTypeMarkTrap)
    return TokenType::TRAP;
  return TokenType::UNKNOWN;
}

} // namespace Puzzle::Runtime::Functions