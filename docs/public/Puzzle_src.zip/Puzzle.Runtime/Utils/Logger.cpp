import std;
import <Puzzle.Runtime/Utils/Logger.hpp>;

namespace Puzzle::Runtime::Utils {

Logger::Logger(std::string_view title, std::string_view filePath)
    : title_(title) {
#ifdef _DEBUG
  minLevel_ = LogLevel::Debug;
#endif
  setLogFile(filePath);
}

std::string Logger::currentTime() noexcept {
  using namespace std::chrono;
  const auto now = system_clock::now();
  const auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
  const auto localTime = zoned_time{current_zone(), floor<seconds>(now)};
  return std::format("{:%T}.{:03}", localTime, ms.count());
}

Logger::~Logger() {
  if (logFile_.is_open())
    logFile_.close();
}

void Logger::setTitle(const std::string_view newTitle) {
  std::lock_guard lock(mutex_);
  title_ = newTitle;
}

void Logger::setMinLevel(const LogLevel level) noexcept { minLevel_ = level; }

void Logger::setOutputConsole(const bool enabled) noexcept {
  outputConsole_ = enabled;
}

void Logger::setOutputColor(const bool enabled) noexcept {
  outputColor_ = enabled;
}

void Logger::setLogFile(std::string_view filePath) const {
  std::lock_guard lock(mutex_);
  if (logFile_.is_open())
    logFile_.close();

  if (filePath.empty())
    return;
  logFile_.open(filePath.data(), std::ios::app);
  if (!logFile_)
    throw std::runtime_error(
        std::format("Failed to open log file: '{}'.", filePath));
}

} // namespace Puzzle::Runtime::Utils