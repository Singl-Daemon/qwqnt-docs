import std;
import <Puzzle.Runtime/Utils/ArgsParser.hpp>;

namespace Puzzle::Runtime::Utils {

ArgsParser::ArgsParser(const int argc, const char *argv[]) {
  for (int i = 1; i < argc; ++i) {
    std::string_view arg{argv[i]};
    if (!(arg.size() > 2 && arg.starts_with("--")))
      throw std::invalid_argument(std::format("Unexpected token: '{}'.", arg));

    std::string key{arg.substr(2)};
    std::string value =
        i + 1 >= argc || std::string_view{argv[i + 1]}.starts_with("--")
            ? "true"
            : argv[++i];
    args_.emplace(std::move(key), std::move(value));
  }
}

bool ArgsParser::has(const std::string_view key) const noexcept {
  return args_.contains(std::string(key));
}

std::string
ArgsParser::get(const std::string_view key,
                const std::string_view defaultValue) const noexcept {
  const auto it = args_.find(std::string(key));
  return it != args_.end() ? it->second : std::string(defaultValue);
}

} // namespace Puzzle::Runtime::Utils