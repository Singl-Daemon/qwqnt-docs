import std;
namespace Puzzle::Runtime::Utils::Flag::literals {
constexpr auto operator"" _flag(const char *s, std::size_t n) -> std::string {
  std::string out;
  out.reserve(n + 6); // "flag{" + content + "}"
  out.append("flag{", 5);
  out.append(s, n);
  out.push_back('}');
  return out;
}
} // namespace Puzzle::Runtime::Utils::Flag::literals