#pragma once
import std;
import <Puzzle.Runtime/Global.hpp>;

namespace Puzzle::Runtime::Utils {

class Logger {
  enum class LogLevel { Debug, Info, Warning, Error, Fatal };

  struct LogStyle {
    std::string name{};
    std::string colorCode{};
  };

  std::string title_;
  LogLevel minLevel_{LogLevel::Info};
  bool outputConsole_{true};
  bool outputColor_{true};
  mutable std::ofstream logFile_;
  mutable std::mutex mutex_;

  inline static const std::unordered_map<LogLevel, LogStyle> logStyles_{
      {LogLevel::Debug, {"DEBUG", "\033[36m"}},  // Cyan
      {LogLevel::Info, {"INFO", "\033[32m"}},    // Green
      {LogLevel::Warning, {"WARN", "\033[33m"}}, // Yellow
      {LogLevel::Error, {"ERROR", "\033[31m"}},  // Red
      {LogLevel::Fatal, {"FATAL", "\033[35m"}}   // Magenta
  };

  inline static const std::string colorReset = "\033[0m";

  PUZZLE_RUNTIME_NDAPI static std::string currentTime() noexcept;

  template <typename... Args>
  void logImpl(const LogLevel level, std::format_string<Args...> fmt,
               Args &&...args) const {
    if (level < minLevel_)
      return;

    const auto time = currentTime();
    const auto &[name, colorCode] = logStyles_.at(level);
    const auto message = std::format(fmt, std::forward<Args>(args)...);

    std::lock_guard lock(mutex_);
    if (outputConsole_) {
      if (outputColor_) {
        if (title_.empty()) {
          std::println("{0}[{1} {2}]{3} {4}", colorCode, time, name, colorReset,
                       message);
        } else {
          std::println("{0}[{1} {2}]{3} [{4}] {5}", colorCode, time, name,
                       colorReset, title_, message);
        }
      } else {
        if (title_.empty()) {
          std::println("[{} {}] {}", time, name, message);
        } else {
          std::println("[{} {}] [{}] {}", time, name, title_, message);
        }
      }
    }

    if (logFile_.is_open()) {
      if (title_.empty()) {
        std::println(logFile_, "[{} {}] {}", time, name, message);
      } else {
        std::println(logFile_, "[{} {}] [{}] {}", time, name, title_, message);
      }
      logFile_.flush();
    }
  }

public:
  PUZZLE_RUNTIME_NDAPI explicit Logger(std::string_view title = "",
                                       std::string_view filePath = {});

 PUZZLE_RUNTIME_NDAPI ~Logger();

  PUZZLE_RUNTIME_NDAPI void setTitle(const std::string_view newTitle);

  PUZZLE_RUNTIME_NDAPI void setMinLevel(const LogLevel level) noexcept;

  PUZZLE_RUNTIME_NDAPI void setOutputConsole(const bool enabled) noexcept;

  PUZZLE_RUNTIME_NDAPI void setOutputColor(const bool enabled) noexcept;

  PUZZLE_RUNTIME_NDAPI void setLogFile(std::string_view filePath) const;

#ifdef _DEBUG
  template <typename... Args>
  void debug(std::format_string<Args...> fmt, Args &&...args) const {
    logImpl(LogLevel::Debug, fmt, std::forward<Args>(args)...);
  }
#else
  template <typename... Args>
  static void debug(std::format_string<Args...>, Args &&...) {
    // No-op in release builds
  }
#endif

  template <typename... Args>
  void info(std::format_string<Args...> fmt, Args &&...args) const {
    logImpl(LogLevel::Info, fmt, std::forward<Args>(args)...);
  }

  template <typename... Args>
  void warn(std::format_string<Args...> fmt, Args &&...args) const {
    logImpl(LogLevel::Warning, fmt, std::forward<Args>(args)...);
  }

  template <typename... Args>
  void error(std::format_string<Args...> fmt, Args &&...args) const {
    logImpl(LogLevel::Error, fmt, std::forward<Args>(args)...);
  }

  template <typename... Args>
  void fatal(std::format_string<Args...> fmt, Args &&...args) const {
    logImpl(LogLevel::Fatal, fmt, std::forward<Args>(args)...);
  }

  template <typename... Args>
  void log(LogLevel level, std::format_string<Args...> fmt,
           Args &&...args) const {
#ifndef DEBUG
    if (level == LogLevel::Debug)
      return;
#endif
    logImpl(level, fmt, std::forward<Args>(args)...);
  }
};
} // namespace Puzzle::Runtime::Utils