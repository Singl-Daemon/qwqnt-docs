#pragma once
import std;
import <Puzzle.Runtime/Global.hpp>;

namespace Puzzle::Runtime::Utils {

class ArgsParser {
  std::unordered_map<std::string, std::string> args_;

public:
  PUZZLE_RUNTIME_API explicit ArgsParser(const int argc, const char *argv[]);

  PUZZLE_RUNTIME_NDAPI bool has(const std::string_view key) const noexcept;

  PUZZLE_RUNTIME_NDAPI std::string
  get(const std::string_view key,
      const std::string_view defaultValue) const noexcept;
};

} // namespace Puzzle::Runtime::Utils
